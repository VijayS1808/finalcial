package com.maheshpai.financialhub;

import com.maheshpai.financialhub.service.EmailService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EmailServiceTest {
    @Test void usesConfiguredSenderAndPublicBackendUrl() {
        JavaMailSender sender = mock(JavaMailSender.class);
        EmailService service = new EmailService();
        ReflectionTestUtils.setField(service, "mailSender", sender);
        ReflectionTestUtils.setField(service, "backendUrl", "https://example.onrender.com/");
        ReflectionTestUtils.setField(service, "sender", "sender@example.com");
        service.sendPasswordResetEmail("admin@example.com", "test-token");
        ArgumentCaptor<SimpleMailMessage> c = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(sender).send(c.capture());
        assertEquals("sender@example.com", c.getValue().getFrom());
        assertTrue(c.getValue().getText().contains("https://example.onrender.com/admin/reset-password.html?token=test-token"));
        assertFalse(c.getValue().getText().contains("localhost"));
    }
}
