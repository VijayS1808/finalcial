package com.maheshpai.financialhub;

import com.maheshpai.financialhub.entity.*;
import com.maheshpai.financialhub.repository.*;
import com.maheshpai.financialhub.service.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mail.MailSendException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest @AutoConfigureMockMvc
class FinancialhubApplicationTests {
    @Autowired MockMvc mvc;
    @Autowired AdminRepository admins;
    @Autowired PasswordResetTokenRepository tokens;
    @Autowired PasswordResetService reset;
    @Autowired PasswordEncoder encoder;
    @Autowired GoogleAdminService google;
    @MockBean EmailService email;

    @BeforeEach void clean() {
        tokens.deleteAll();
        Admin a = admins.findByUsername("admin").orElseThrow();
        a.setPassword(encoder.encode("Original-password-2026"));
        admins.save(a);
    }
    @Test void googleButtonStartsAuthorizationWithoutChangingHtml() throws Exception {
        mvc.perform(get("/login/oauth2/code/google")).andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("/oauth2/authorization/google"));
        mvc.perform(get("/oauth2/authorization/google")).andExpect(status().is3xxRedirection())
            .andExpect(header().string("Location", org.hamcrest.Matchers.containsString("accounts.google.com")))
            .andExpect(header().string("Location", org.hamcrest.Matchers.containsString("financialhub-test.onrender.com")));
    }
    @Test void invalidCallbackDoesNotRestartLogin() throws Exception {
        mvc.perform(get("/login/oauth2/code/google?error=access_denied&state=invalid"))
            .andExpect(redirectedUrl("/admin/login.html?error"));
    }
    @Test void csrfEndpointAndRequestContract() throws Exception {
        mvc.perform(get("/admin/api/password-reset/csrf"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.token").isNotEmpty())
            .andExpect(jsonPath("$.headerName").value("X-CSRF-TOKEN"));
        mvc.perform(post("/admin/api/password-reset/request").contentType("application/json")
            .content("{\"email\":\"admin@example.com\"}")).andExpect(status().isForbidden());
        mvc.perform(post("/admin/api/password-reset/request").with(csrf()).contentType("application/json")
            .content("{\"email\":\"admin@example.com\"}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("accepted"));
        verify(email).sendPasswordResetEmail(eq("admin@example.com"), anyString());
    }
    @Test void unknownEmailHasSameAcknowledgement() throws Exception {
        mvc.perform(post("/admin/api/password-reset/request").with(csrf()).contentType("application/json")
            .content("{\"email\":\"unknown@example.com\"}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("accepted"));
        verifyNoInteractions(email);
    }
    String requestToken() {
        reset.request("ADMIN@example.com", true);
        ArgumentCaptor<String> c = ArgumentCaptor.forClass(String.class);
        verify(email, atLeastOnce()).sendPasswordResetEmail(eq("admin@example.com"), c.capture());
        return c.getValue();
    }
    @Test void legacyResetPageChangesPasswordAndTokenIsSingleUse() throws Exception {
        String raw = requestToken();
        assertEquals(PasswordResetService.hash(raw), tokens.findAll().get(0).getToken());
        mvc.perform(post("/api/auth/reset-password").param("token", raw).param("newPassword", "New-password-2026"))
            .andExpect(status().isOk());
        assertTrue(encoder.matches("New-password-2026", admins.findByUsername("admin").orElseThrow().getPassword()));
        assertFalse(reset.confirm(raw, "Another-password"));
        mvc.perform(post("/admin/login-submit").param("username", "admin").param("password", "New-password-2026"))
            .andExpect(redirectedUrl("/admin/dashboard.html"));
    }
    @Test void expiredInvalidAndShortPasswordRejected() {
        String raw = requestToken();
        assertFalse(reset.confirm(raw, "short"));
        assertFalse(reset.confirm("bad-token", "Valid-password"));
        PasswordResetToken t = tokens.findAll().get(0);
        t.setExpiryDate(LocalDateTime.now().minusMinutes(1)); tokens.save(t);
        assertFalse(reset.confirm(raw, "Valid-password"));
        assertEquals(0, tokens.count());
    }
    @Test void repeatedRequestReplacesPriorToken() {
        String old = requestToken(); String fresh = requestToken();
        assertEquals(1, tokens.count());
        assertFalse(reset.confirm(old, "Valid-password"));
        assertTrue(reset.confirm(fresh, "Valid-password"));
    }
    @Test void smtpFailureRemovesUnsentToken() {
        doThrow(new MailSendException("test delivery failure")).when(email).sendPasswordResetEmail(anyString(), anyString());
        reset.request("admin@example.com", true);
        assertEquals(0, tokens.count());
    }
    @Test void jsonConfirmContract() throws Exception {
        String raw = requestToken();
        mvc.perform(post("/admin/api/password-reset/confirm").with(csrf()).contentType("application/json")
            .content("{\"token\":\"" + raw + "\",\"password\":\"New-password-2026\"}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("reset"));
    }
    OidcUser user(String address, boolean verified) {
        OidcIdToken token = new OidcIdToken("mock", Instant.now(), Instant.now().plusSeconds(60),
            Map.of("sub", "123", "email", address, "email_verified", verified));
        return new DefaultOidcUser(List.of(new SimpleGrantedAuthority("OIDC_USER")), token);
    }
    @Test void googleOnlyAllowsVerifiedRegisteredAdmins() {
        assertTrue(google.authorize(user("admin@example.com", true)).getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        assertThrows(OAuth2AuthenticationException.class, () -> google.authorize(user("unknown@example.com", true)));
        assertThrows(OAuth2AuthenticationException.class, () -> google.authorize(user("admin@example.com", false)));
        Admin admin = admins.findByUsername("admin").orElseThrow();
        admin.setRole("ROLE_USER"); admins.save(admin);
        try { assertThrows(OAuth2AuthenticationException.class, () -> google.authorize(user("admin@example.com", true))); }
        finally { admin.setRole("ROLE_ADMIN"); admins.save(admin); }
    }
    @Test void protectedDashboardRequiresLogin() throws Exception {
        mvc.perform(get("/admin/dashboard.html")).andExpect(status().is3xxRedirection());
        mvc.perform(get("/admin/api/blogs")).andExpect(status().isOk());
    }
}
