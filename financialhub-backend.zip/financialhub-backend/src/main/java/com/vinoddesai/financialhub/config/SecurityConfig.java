package com.maheshpai.financialhub.config;

import com.maheshpai.financialhub.service.GoogleAdminService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;

@Configuration
public class SecurityConfig {
    @Bean
    public PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

    // The existing forgot-password page explicitly requests a session-bound CSRF token.
    @Bean @Order(1)
    SecurityFilterChain resetSecurity(HttpSecurity http) throws Exception {
        http.securityMatcher("/admin/api/password-reset/**")
            .authorizeHttpRequests(a -> a.anyRequest().permitAll());
        return http.build();
    }

    @Bean @Order(2)
    SecurityFilterChain securityFilterChain(HttpSecurity http, GoogleAdminService google) throws Exception {
        http.csrf(c -> c.disable()) // Retain compatibility with the unchanged legacy forms/dashboard.
            .authorizeHttpRequests(a -> a
                .requestMatchers(HttpMethod.GET, "/admin/api/blogs", "/admin/api/events", "/admin/api/gallery").permitAll()
                .requestMatchers("/admin/login.html", "/admin/forgot-password.html", "/admin/reset-password.html", "/admin/login-submit").permitAll()
                .requestMatchers("/admin/dashboard.html", "/admin/api/**").hasRole("ADMIN")
                .anyRequest().permitAll())
            .formLogin(f -> f.loginPage("/admin/login.html")
                .loginProcessingUrl("/admin/login-submit")
                .failureUrl("/admin/login.html?error")
                .defaultSuccessUrl("/admin/dashboard.html", true).permitAll())
            .oauth2Login(o -> o.loginPage("/admin/login.html")
                .userInfoEndpoint(u -> u.oidcUserService(google))
                .defaultSuccessUrl("/admin/dashboard.html", true)
                .failureUrl("/admin/login.html?error"))
            .logout(l -> l.logoutUrl("/admin/logout").logoutSuccessUrl("/admin/login.html?logout").permitAll());
        // Keep the supplied HTML byte-for-byte: its Google button points at the callback.
        // Only a bare GET starts login; actual callbacks (including errors) reach Spring.
        http.addFilterBefore(new OncePerRequestFilter() {
            @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                    FilterChain chain) throws ServletException, IOException {
                if ("GET".equals(req.getMethod()) && (req.getContextPath() + "/login/oauth2/code/google").equals(req.getRequestURI())
                        && req.getQueryString() == null) {
                    res.sendRedirect("/oauth2/authorization/google");
                    return;
                }
                chain.doFilter(req, res);
            }
        }, OAuth2LoginAuthenticationFilter.class);
        return http.build();
    }
}
