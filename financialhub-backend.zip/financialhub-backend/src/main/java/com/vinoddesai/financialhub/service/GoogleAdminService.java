package com.maheshpai.financialhub.service;

import com.maheshpai.financialhub.entity.Admin;
import com.maheshpai.financialhub.repository.AdminRepository;
import java.util.List;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Service;

@Service
public class GoogleAdminService implements OAuth2UserService<OidcUserRequest, OidcUser> {
    private final AdminRepository admins;
    private final OidcUserService delegate = new OidcUserService();
    public GoogleAdminService(AdminRepository admins) { this.admins = admins; }
    @Override public OidcUser loadUser(OidcUserRequest request) {
        return authorize(delegate.loadUser(request));
    }
    public OidcUser authorize(OidcUser user) {
        if (!Boolean.TRUE.equals(user.getEmailVerified()) || user.getEmail() == null) throw denied();
        Admin admin = admins.findByEmailIgnoreCase(user.getEmail().trim()).orElseThrow(this::denied);
        if (!"ROLE_ADMIN".equals(admin.getRole())) throw denied();
        return new DefaultOidcUser(List.of(new SimpleGrantedAuthority("ROLE_ADMIN")),
                user.getIdToken(), user.getUserInfo(), "email");
    }
    private OAuth2AuthenticationException denied() {
        return new OAuth2AuthenticationException(new OAuth2Error("access_denied"), "Administrator account required.");
    }
}
