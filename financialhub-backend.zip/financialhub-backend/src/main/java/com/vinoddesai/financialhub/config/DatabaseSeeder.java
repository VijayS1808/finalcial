package com.maheshpai.financialhub.config;

import com.maheshpai.financialhub.entity.Admin;
import com.maheshpai.financialhub.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DatabaseSeeder {
    @Bean
    CommandLineRunner initDatabase(AdminRepository admins, PasswordEncoder encoder,
            @Value("${app.admin.username:admin}") String username,
            @Value("${app.admin.email:}") String email,
            @Value("${app.admin.password:}") String password) {
        return args -> {
            if (admins.count() != 0) return;
            if (email.isBlank() || password.length() < 12 || password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72)
                throw new IllegalStateException("Empty database: set ADMIN_EMAIL and ADMIN_PASSWORD (12+ characters, max 72 UTF-8 bytes).");
            Admin admin = new Admin();
            admin.setUsername(username);
            admin.setEmail(email.trim().toLowerCase(java.util.Locale.ROOT));
            admin.setPassword(encoder.encode(password));
            admin.setRole("ROLE_ADMIN");
            admins.save(admin);
        };
    }
}
