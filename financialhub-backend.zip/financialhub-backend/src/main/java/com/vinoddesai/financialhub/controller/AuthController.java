package com.maheshpai.financialhub.controller;

import com.maheshpai.financialhub.service.PasswordResetService;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;

@RestController
public class AuthController {
    private final PasswordResetService reset;
    public AuthController(PasswordResetService reset) { this.reset = reset; }

    @GetMapping("/admin/api/password-reset/csrf")
    public ResponseEntity<?> csrf(CsrfToken csrf) {
        return ResponseEntity.ok().header("Cache-Control", "no-store")
                .body(Map.of("token", csrf.getToken(), "headerName", csrf.getHeaderName()));
    }
    @PostMapping("/admin/api/password-reset/request")
    public Map<String, String> request(@RequestBody Map<String, String> body) {
        reset.request(body.get("email"), true);
        return Map.of("status", "accepted");
    }
    @PostMapping("/admin/api/password-reset/confirm")
    public ResponseEntity<?> confirm(@RequestBody Map<String, String> body) {
        return reset.confirm(body.get("token"), body.get("password"))
                ? ResponseEntity.ok(Map.of("status", "reset"))
                : ResponseEntity.badRequest().body(Map.of("status", "invalid"));
    }
    // Preserve the existing reset page's form-encoded API contract.
    @PostMapping("/api/auth/reset-password")
    public ResponseEntity<String> legacyConfirm(@RequestParam String token, @RequestParam String newPassword) {
        return reset.confirm(token, newPassword) ? ResponseEntity.ok("Password updated successfully.")
                : ResponseEntity.badRequest().body("Invalid or expired reset link. Password must be at least 6 characters and at most 72 UTF-8 bytes.");
    }
    @PostMapping("/api/auth/forgot-password")
    public Map<String, String> legacyRequest(@RequestParam String username) {
        reset.request(username, false);
        return Map.of("message", "If the account exists, a reset link has been sent.");
    }
}
