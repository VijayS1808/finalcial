package com.maheshpai.financialhub.service;

import com.maheshpai.financialhub.entity.Admin;
import com.maheshpai.financialhub.entity.PasswordResetToken;
import com.maheshpai.financialhub.repository.AdminRepository;
import com.maheshpai.financialhub.repository.PasswordResetTokenRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.Optional;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PasswordResetService {
    private static final Logger log = LoggerFactory.getLogger(PasswordResetService.class);
    private final AdminRepository admins;
    private final PasswordResetTokenRepository tokens;
    private final EmailService email;
    private final PasswordEncoder encoder;
    private final EntityManager em;
    public PasswordResetService(AdminRepository admins, PasswordResetTokenRepository tokens,
            EmailService email, PasswordEncoder encoder, EntityManager em) {
        this.admins = admins; this.tokens = tokens; this.email = email; this.encoder = encoder; this.em = em;
    }
    @Transactional
    public void request(String identifier, boolean byEmail) {
        if (identifier == null || identifier.isBlank() || identifier.length() > 254) return;
        Optional<Admin> found = byEmail ? admins.findByEmailIgnoreCase(identifier.trim()) : admins.findByUsername(identifier.trim());
        if (found.isEmpty()) return;
        Admin admin = found.get();
        em.lock(admin, LockModeType.PESSIMISTIC_WRITE);
        tokens.deleteByAdmin(admin);
        tokens.flush(); // Delete the old unique admin_id row before inserting its replacement.
        String raw = UUID.randomUUID().toString();
        PasswordResetToken token = tokens.saveAndFlush(new PasswordResetToken(hash(raw), admin, 15));
        try { email.sendPasswordResetEmail(admin.getEmail(), raw); }
        catch (org.springframework.mail.MailException ex) {
            tokens.delete(token);
            log.error("Password reset mail delivery failed; check SMTP credentials, sender and network settings ({})", ex.getClass().getSimpleName());
        }
    }
    @Transactional
    public boolean confirm(String raw, String password) {
        if (raw == null || raw.length() > 128 || password == null || password.length() < 6
                || password.getBytes(StandardCharsets.UTF_8).length > 72) return false;
        Optional<PasswordResetToken> found = tokens.findByToken(hash(raw));
        if (found.isEmpty()) return false;
        PasswordResetToken token = found.get();
        if (!token.getExpiryDate().isAfter(LocalDateTime.now())) {
            tokens.delete(token); return false;
        }
        Admin admin = token.getAdmin();
        admin.setPassword(encoder.encode(password));
        admins.save(admin);
        tokens.delete(token);
        tokens.flush();
        return true;
    }
    public static String hash(String token) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8))); }
        catch (NoSuchAlgorithmException ex) { throw new IllegalStateException(ex); }
    }
}
