# Financial Hub: Netlify frontend + Render backend

Prepared 2 November 2026 from the financialhub.zip supplied with this request.

## 1. What changed and what stayed unchanged

Every one of the 52 original frontend files is preserved byte-for-byte: HTML pages, CSS, JavaScript, images and components. No page layout, text, button, styling or script was edited. The separate frontend package adds only `_redirects` for Netlify routing.

Backend changes:
- Enabled Google OpenID Connect login. The original Google button mistakenly points to the callback URL; a backend compatibility filter redirects a bare callback GET to the correct authorization-start endpoint. Real callbacks still go through Spring Security validation.
- Only Google accounts with a verified email matching an existing ROLE_ADMIN database record can sign in. This project has an administrator login, not a public customer-registration system. Google does not create arbitrary administrator accounts.
- Implemented the JSON/CSRF APIs already called by your forgot-password page, with email lookup. Kept the form-encoded endpoint used by your existing reset page.
- Configured reset email sender and public URL through environment variables instead of placeholders and localhost.
- Added 15-minute, hashed, single-use reset tokens; replacement of old tokens; password validation; transaction locking; and safe mail-failure logging. Existing reset links issued before this update must be requested again.
- Fixed the first-admin seed: it now sets ROLE_ADMIN, uses your configured email and password, and never prints a password. It only creates an account when the admins table is empty.
- Replaced embedded database, mail and OAuth credentials with environment variables; removed the duplicate OAuth dependency.
- Added Java 21 Docker deployment and automated authentication tests.

The frontend remains unchanged, including the existing six-character reset-password minimum. The backend enforces this same minimum and BCrypt's 72-byte limit. New bootstrap passwords require at least 12 characters.

## 2. Files and hosting layout

- `financialhub.zip`: full corrected source project, original frontend, uploads, deployment guide and validation report.
- `financialhub-backend.zip`: Render-ready project. The original static files are intentionally included: Render serves the unchanged administrator login/dashboard/reset pages so session cookies remain on one host.
- `financialhub-frontend.zip`: static frontend for Netlify, with `_redirects` added.
- `DEPLOYMENT.md`: this guide.

Public visitors use `https://YOUR-SITE.netlify.app`. Opening an `/admin/...` page moves the browser to `https://YOUR-BACKEND.onrender.com`. Google login, session cookies and password reset stay on that Render hostname. Public gallery/blog/event/contact requests use Netlify proxies. This avoids modifying your frontend files or relying on third-party session cookies.

The frontend zip also retains the original admin files, but forced redirects send requests for those pages to Render. Use the supplied routing file; do not add a catch-all SPA rule.

## 3. Before deployment

1. Use a private Git repository for the backend source. Never upload the original archive's credentials, logs or compiled target directory.
2. Replace/rotate the database password, Gmail password/app password and Google OAuth client secret that were embedded in the original project. The corrected source contains placeholders only.
3. Have accounts for Render, Netlify, Google Cloud and a reachable MariaDB database.
4. Use a PAID Render web service with SMTP port 587 access for the included Gmail mail implementation. Render Free blocks outbound SMTP ports 25, 465 and 587. This package does not add an HTTP email provider. Free Render will not deliver these Gmail reset emails.
5. Back up your existing database and uploaded media before pointing the corrected application at it. Your archive contains source and media, not a database dump.

## 4. Database setup

The application uses MariaDB, not PostgreSQL. Render's managed PostgreSQL URL cannot be placed in DB_URL for this project. Use a separately hosted MariaDB service reachable from Render, with a database/schema named `financialhub` (or change the schema in the URL).

Obtain the host, port, database name, username and password from your database provider. Allow the Render service's outbound connections according to that provider's firewall rules. Require TLS using the provider's supported certificate setup.

Example only:

```text
DB_URL=jdbc:mariadb://db.example.com:3306/financialhub?sslMode=verify-full
DB_USERNAME=financialhub
DB_PASSWORD=your-new-database-password
```

`localhost` on Render means the Render container, not your laptop or external database. Do not use localhost in the production DB_URL. Do not put the username/password into the URL. If your provider requires a private CA, configure its certificate trust instructions; do not disable TLS verification just to bypass a connection error.

The application retains `spring.jpa.hibernate.ddl-auto=update`, so its database user needs the necessary table-creation/alteration permissions. Use a backup when upgrading an existing database.

### Existing admin database

ADMIN_EMAIL and ADMIN_PASSWORD do not overwrite existing records. Verify the intended administrator in the database:

```sql
SELECT id, username, email, role FROM admins;
```

If needed, update only your intended account, replacing the example email and username:

```sql
UPDATE admins
SET email = 'your-admin-google-account@gmail.com', role = 'ROLE_ADMIN'
WHERE username = 'admin';
```

Do not write a plaintext password into the password column. Use the forgot-password flow after mail is configured. Google matches the database email, not the ADMIN_EMAIL environment variable alone.

## 5. Configure Google login

1. Open Google Cloud Console: https://console.cloud.google.com/ and select/create your project.
2. Open Google Auth Platform / APIs & Services credentials, depending on the console layout.
3. Configure branding/consent, support email and audience. During Testing, add the intended administrator Google account as a test user where required.
4. Create an OAuth client of type **Web application**.
5. Set the authorized redirect URI to the EXACT backend callback:

```text
https://YOUR-BACKEND.onrender.com/login/oauth2/code/google
```

6. If you use Authorized JavaScript origins, add `https://YOUR-BACKEND.onrender.com`. The implemented server-side flow depends on the redirect URI; the frontend Netlify origin is not the callback.
7. Copy the client ID and new client secret into Render's GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables.
8. The admin's email in `admins.email` must match the verified Google account. Unknown accounts are deliberately rejected.

Do not put `/oauth2/authorization/google` in the redirect-URI field: that is the START URL. Do not add a trailing slash to the callback.

For local development, add a second redirect URI `http://localhost:8080/login/oauth2/code/google`, use BACKEND_URL=http://localhost:8080 and COOKIE_SECURE=false. Keep the production URI too.

## 6. Configure Gmail for reset messages

1. Sign in to the Gmail account that will SEND mail.
2. Enable Google 2-Step Verification and generate an App Password: https://myaccount.google.com/apppasswords . Availability depends on your account/organization settings.
3. Put that app password in MAIL_PASSWORD, not your normal Gmail sign-in password. Remove display spaces when copying it.
4. Set MAIL_USERNAME to the sender Gmail address. The reset-email From address uses this value.
5. The recipient is the email stored in the administrator's database record. It may differ from the sender.
6. Keep MAIL_HOST=smtp.gmail.com and MAIL_PORT=587. The included configuration requires STARTTLS.

If your Google account cannot create app passwords, use an SMTP provider supporting authenticated STARTTLS on port 587 and set MAIL_HOST, MAIL_PORT, MAIL_USERNAME and MAIL_PASSWORD accordingly. The sender must be permitted by that provider.

## 7. Deploy backend to Render

1. Extract `financialhub-backend.zip`. Open its `financialhub-backend` folder. `pom.xml`, `Dockerfile`, `src/` and `uploads/` are at this level.
2. Push this folder's CONTENTS to a new private Git repository. If you instead push the enclosing folder, set Render's Root Directory to `financialhub-backend`.
3. In Render select **New > Web Service**, connect the repository and choose **Docker** runtime. Java is built through Docker.
4. Dockerfile path: `./Dockerfile`. Docker context: project root. Do not supply a Node build command. Leave Docker command override blank; the Dockerfile supplies the startup command.
5. Choose a paid instance for SMTP and persistent media. Choose the desired region, preferably near the MariaDB service.
6. Note the assigned `https://...onrender.com` URL. Use it as BACKEND_URL and in Google Cloud's redirect URI before testing login. No trailing slash in BACKEND_URL.
7. Add all environment variables from the table below. Use actual secrets, without surrounding quotation marks. `.env.example` is a reference only; Spring Boot does not automatically load it.
8. For uploaded files to persist, add a Render persistent disk mounted at `/app/uploads`. This matches the original relative upload paths; no frontend changes are needed.
9. Start deployment. The Docker build runs `mvn -B clean verify` with Java 21 and mocked email/Google tests before packaging the application.
10. Health-check path: `/admin/login.html`. Successful startup should show the app listening on Render's PORT. This health check confirms the web app is up, not that Google/email delivery has been verified.
11. Open the Render URL's `/admin/login.html`. First test username/password, then Google, then password reset.
12. After the first successful initialization, remove ADMIN_PASSWORD from Render Environment if desired. Existing admins are not reseeded. A new empty database will require it again.

| Variable | Required value |
|---|---|
| DB_URL | Full MariaDB JDBC URL, including host, port, schema and provider TLS options |
| DB_USERNAME | MariaDB account |
| DB_PASSWORD | New database password |
| BACKEND_URL | `https://YOUR-BACKEND.onrender.com` |
| COOKIE_SECURE | `true` for production HTTPS |
| GOOGLE_CLIENT_ID | Web OAuth client ID ending in `.apps.googleusercontent.com` |
| GOOGLE_CLIENT_SECRET | New OAuth secret |
| MAIL_HOST | `smtp.gmail.com` or your supported SMTP host |
| MAIL_PORT | `587` |
| MAIL_USERNAME | Sending email account |
| MAIL_PASSWORD | Gmail App Password / SMTP credential |
| ADMIN_USERNAME | `admin`, or your chosen initial username |
| ADMIN_EMAIL | Administrator's Google account/email; also contact-notification recipient |
| ADMIN_PASSWORD | Unique first-admin password, 12+ characters, max 72 UTF-8 bytes |

Render supplies PORT; the app reads it automatically. No database, Google or mail secrets belong on Netlify.

### Existing uploaded media on a persistent disk

A mounted disk hides the image's baked `/app/uploads` files. For existing data, copy the original `uploads/` contents into the mounted disk using Render's supported shell/SSH transfer facilities, preserving filenames and the `gallery/` subfolder. Transfer the corresponding database separately. Do not assume the source zip restores database records or automatically populates a newly mounted disk. Verify existing media URLs after migration.

## 8. Deploy frontend to Netlify

1. Extract `financialhub-frontend.zip` and open `financialhub-frontend/`.
2. Open `_redirects` in a text editor. Replace EVERY `YOUR-BACKEND` with your actual Render service hostname prefix. Example: for `https://financialhub-api-abc.onrender.com`, use `financialhub-api-abc`.
3. Keep all rules in their supplied order. `/admin/api/*` must appear before `/admin/*`. Preserve `200!` and `302!` markers.
4. For manual deployment, open Netlify > Add new project/site > Deploy manually, then drop the extracted folder containing `index.html`, `_redirects`, `assets`, `components`, `pages` and `admin`.
5. For Git deployment, commit that folder's CONTENTS to a frontend repository. Build command: leave blank. Publish directory: `.`. If the enclosing folder is in your repo, set the base/publish location to that folder instead.
6. Netlify's environment does not substitute placeholders inside `_redirects`; you must edit the file with the actual backend hostname.
7. Open the Netlify URL and check home, blogs, events, gallery and contact. Click Admin/login and confirm the browser moves to Render.
8. If you change the Render hostname, update `_redirects`, BACKEND_URL and the Google callback, then redeploy the affected services.

The non-forced uploads proxy lets existing static images win when they exist in the Netlify frontend. New backend uploads are proxied from Render. Public API calls remain same-origin from the browser, so wildcard CORS configuration is unnecessary.

## 9. Acceptance checks after deployment

- Public frontend: inspect the main pages; verify the layout is unchanged.
- Unauthenticated dashboard: visit Render `/admin/dashboard.html` in a private window; it should redirect to login.
- Password login: use the initial admin credentials; verify dashboard access.
- Google: use the registered admin Google email; verify dashboard access. Try an unrelated Google email; it must be rejected.
- Forgot password: enter the registered database email on Render `/admin/forgot-password.html`; verify receipt of the message (including spam folder).
- Email link: it must start with your actual Render hostname, not localhost or the Netlify hostname.
- Reset: choose matching passwords, submit, and sign in with the new password. The old password should fail.
- Token reuse: reopen the same reset link and submit again; it must fail.
- Replacement: request two reset emails; only the newest link should work.
- Expiry: a link older than 15 minutes must fail.
- Unknown email: the forgot form should show the same generic acknowledgement and send no message.
- CSRF: the browser's network log should show `/admin/api/password-reset/csrf` returning JSON, followed by a request POST with the returned header.
- Restart: verify database records and persistent uploads remain available after a Render restart/redeploy.

## 10. Troubleshooting

| Symptom | Check |
|---|---|
| `redirect_uri_mismatch` | Exact callback in Google Cloud must match BACKEND_URL + `/login/oauth2/code/google`, including HTTPS and hostname. |
| Google returns to login with `?error` | Google test-user configuration, verified email, existing admins.email and ROLE_ADMIN; check client credentials too. The unchanged login page shows a generic error. |
| Forgot form says server API is unavailable | Correct backend version, routing, HTTP status, and JSON response; an HTML fallback is not the reset API. |
| Forgot form says session expired | Open the Render URL directly, allow session cookies, refresh and retry. Production COOKIE_SECURE needs HTTPS. |
| No email despite accepted message | Generic response intentionally does not reveal account existence or delivery. Check database email, spam, app password, paid Render SMTP access and backend logs for `Password reset mail delivery failed`. |
| Mail authentication failure | Use an App Password and correct sender, not the ordinary Google account password. |
| Database connection refused | External MariaDB host/port, firewall, TLS and credentials; localhost is wrong on Render. |
| App fails with empty database message | Set ADMIN_EMAIL and a strong ADMIN_PASSWORD. |
| Existing admin cannot sign in | Verify email, ROLE_ADMIN and BCrypt password. Environment bootstrap values do not overwrite an existing account. |
| Blank blog/gallery lists | Backend database must contain the original records; check Netlify public API proxies and response status. |
| Uploads disappear | Attach disk at `/app/uploads` and migrate existing media. |
| Render build cannot download dependencies | Check Maven Central connectivity; retry after connectivity is restored. |

## 11. Validation and scope limits

A byte comparison confirmed all 52 original frontend files are identical in the corrected project and Netlify package. Source/configuration checks and ZIP integrity checks were performed. Authentication integration/unit tests were added for the Google-start compatibility route, callback rejection, admin authorization, reset API contracts, CSRF, token hashing/replacement/expiry/reuse, mail failure and configured sender/link.

The Java tests could NOT be executed in the preparation environment: Maven failed while resolving the Spring Boot parent from Maven Central because DNS/network access was unavailable. The local runtime also only provided Java 17; the delivered project and Docker build remain Java 21. There is no claim of a passing build or live Google/SMTP/database verification. Run `./mvnw clean verify` with Java 21 and Maven Central access, or let the supplied Docker build run it before deploying.

No real Google Cloud, Render, Netlify, Gmail or database account was accessed or changed. You must enter credentials and perform the live acceptance checks above.

The existing legacy dashboard/form authentication retains its previous CSRF behavior to preserve your unchanged scripts. CSRF is enforced for the new reset JSON endpoints. This targeted repair is not a complete security audit; it does not introduce public signup, distributed rate limiting, session revocation after password changes, or redesign the legacy forms. Backend/static media configuration and unrelated business features remain as supplied.

## 12. Official references

- Render Docker: https://render.com/docs/docker
- Render web services and PORT: https://render.com/docs/web-services
- Render free-service limits, including SMTP: https://render.com/docs/free
- Netlify redirects/proxies: https://docs.netlify.com/manage/routing/redirects/rewrites-proxies/
- Netlify routing rules: https://docs.netlify.com/manage/routing/redirects/overview/
- Google OpenID Connect: https://developers.google.com/identity/openid-connect/openid-connect
- Google App Passwords: https://support.google.com/accounts/answer/185833
- Spring Security OAuth login: https://docs.spring.io/spring-security/reference/servlet/oauth2/login/advanced.html
